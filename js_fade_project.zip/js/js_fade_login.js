let i = -1;
let interval;

function test() {
    i++;
    console.log(i);
}

interval = setInterval(test, 1000);

setTimeout(() => {
    clearInterval(interval);
}, 5000);


// 배열을 이용해서 .gallery-con>ul>li*5 배경이미지를 설정
// 배열, for, push, style.background 사용
//  model0 - model4 배열에 저장한 후에, 배경 이미지를 설정
var galleryCon = document.querySelector('.gallery-con');
var galleryConUlLi = document.querySelectorAll('.gallery-con>ul>li');


// [0, 1, 2, 3, 4].forEach(element => {
//     galleryConUlLi[element].style.background="url('/img/model"+element+".jpg') no-repeat 50%/cover";   
// });

// for(let i=0;i<5;i++){
//     a=push("background : url('/img/model"+i+".jpg') no-repeat 50%/cover");
//     galleryConUlLi[i].style.background = new Array();
//     galleryConUlLi[i].style.background = a
// }


// 3초마다 인덱스에 해당하는 ul DOM을 보이기
//  나머지는 보이지 않게 하기

galleryConUlLi.forEach((el, index) => {
    console.log(el, index);
})


// 4까지만 해서 classList 사용
var fadeLi = document.querySelectorAll('.item .item-con ul li');

let j = -1;
function fading() {

    j++;
    galleryConUlLi.forEach((el, i) => {
        if (i === j) {
            el.style.visibility = "visible";
        } else {
            el.style.visibility = "hidden";
        }

    });


    fadeLi.forEach((el, i) => {
        if (i === j) {
            el.classList.add('on');
        } else {
            el.classList.remove('on');
        }
    });


    if (j >= galleryConUlLi.length - 1) {
        j = -1;
    }

}

let interval1 = setInterval(fading, 2000);

(() => { interval1 })();

// setTimeout1(() => {
//     clearInterval(interval1);
// }, 5000);




